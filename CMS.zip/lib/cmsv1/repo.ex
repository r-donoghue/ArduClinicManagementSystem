defmodule Cmsv1.Repo do
  use Ecto.Repo, otp_app: :cmsv1
end
