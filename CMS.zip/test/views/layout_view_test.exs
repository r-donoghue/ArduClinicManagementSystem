defmodule Cmsv1.LayoutViewTest do
  use Cmsv1.ConnCase, async: true
end
