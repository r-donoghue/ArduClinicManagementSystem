defmodule Cmsv1.PageViewTest do
  use Cmsv1.ConnCase, async: true
end
