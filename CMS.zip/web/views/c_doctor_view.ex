defmodule Cmsv1.CDoctorView do
  use Cmsv1.Web, :view
end
