defmodule Cmsv1.InactivityView do
  use Cmsv1.Web, :view
end
