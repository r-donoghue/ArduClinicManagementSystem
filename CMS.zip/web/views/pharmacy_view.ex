defmodule Cmsv1.PharmacyView do
  use Cmsv1.Web, :view
end
