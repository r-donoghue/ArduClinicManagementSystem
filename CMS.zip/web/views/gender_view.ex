defmodule Cmsv1.GenderView do
  use Cmsv1.Web, :view
end
