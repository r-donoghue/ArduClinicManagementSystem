defmodule Cmsv1.RelationshipView do
  use Cmsv1.Web, :view
end
