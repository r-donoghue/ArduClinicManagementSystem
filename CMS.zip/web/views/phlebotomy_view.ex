defmodule Cmsv1.PhlebotomyView do
  use Cmsv1.Web, :view
end
