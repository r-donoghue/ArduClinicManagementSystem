defmodule Cmsv1.VaccinationsView do
  use Cmsv1.Web, :view
end
