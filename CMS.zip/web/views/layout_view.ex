defmodule Cmsv1.LayoutView do
  use Cmsv1.Web, :view
end
