defmodule Cmsv1.PageView do
  use Cmsv1.Web, :view
end
