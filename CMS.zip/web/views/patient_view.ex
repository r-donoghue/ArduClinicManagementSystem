defmodule Cmsv1.PatientView do
  use Cmsv1.Web, :view
end
