defmodule Cmsv1.GPView do
  use Cmsv1.Web, :view
end
