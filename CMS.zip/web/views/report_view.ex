defmodule Cmsv1.ReportView do
    use Cmsv1.Web, :view
  end